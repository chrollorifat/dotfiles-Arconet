#!/usr/bin/env python
# ~*~ coding: utf-8 ~*~

__license__   = 'GPL v3'
__copyright__ = '2021 additions by Ahmed Zaki <azaki00.dev@gmail.com>'
__docformat__ = 'restructuredtext en'

import csv
from collections import defaultdict

from qt.core import (Qt, QApplication, QWidget, QVBoxLayout, QGridLayout, QGroupBox,
                     QLabel, QLineEdit)

from calibre import prints
from calibre.constants import DEBUG
from calibre.gui2 import error_dialog

from calibre_plugins.category_tags.user_categories.formats.base import UserCategoriesFormat

try:
    load_translations()
except NameError:
    prints("Category Tags::user_categories/formats/categories_for_item.py - exception when loading translations")

class CategoriesForItemConfigWidget(QWidget):

    def __init__(self, gui):
        QWidget.__init__(self)
        self.gui = gui
        self.db = self.gui.current_db
        self._init_controls()

    def _init_controls(self):

        l = QVBoxLayout()
        self.setLayout(l)

        csv_groupbox = QGroupBox(_('CSV Options'))
        csv_groupbox_l = QGridLayout()
        csv_groupbox.setLayout(csv_groupbox_l)
        l.addWidget(csv_groupbox)

        self.csv_delimiter_label = QLabel(_('CSV Delimiter'))
        self.csv_delimiter_edit = QLineEdit()
        csv_groupbox_l.addWidget(self.csv_delimiter_label, 0, 0, 1, 1)
        csv_groupbox_l.addWidget(self.csv_delimiter_edit, 0, 1, 1, 1)

    def load_settings(self, settings):
        if settings:
            self.csv_delimiter_edit.setText(settings['csv_delimiter'])

    def save_settings(self):
        settings = {}
        settings['csv_delimiter'] = self.csv_delimiter_edit.text()
        return settings

class CSVCategoriesForItem(UserCategoriesFormat):

    name = 'csv_categories_for_item'
    description = 'CSV: Categories For Item'
    filters = [(_('Categories'), ['csv'])]
    _is_builtin = True

    def to_pivot(self, file_path, settings):
        format_settings = settings.get('format_settings', {})
        csv_delimiter = format_settings.get('csv_delimiter', ',')
        pivot_format = defaultdict(dict)
        with open(file_path, 'r', encoding="utf-8-sig") as f:
            reader = csv.reader(f, delimiter=csv_delimiter, quoting=csv.QUOTE_MINIMAL)
            for idx, row in enumerate(reader):
                if idx == 0:
                    headers = row
                    if not headers == ['item','item_type','categories']:
                        error_dialog(self.gui,
                                    _('Invalid CSV Headers'),
                                    _('CSV headers for this format should be: item, item_type, categories'),
                                    show=True)
                        return {}
                else:
                    item, item_type, imported_categories = row
                    if item_type not in self.all_item_types:
                        error_dialog(self.gui,
                                    _('Invalid item type'),
                                    _('Item type ({}) is not valid. Valid item types are: {}'.fomrat(item_type, self.all_item_types)),
                                    show=True)
                        return {}                    
                    imported_categories = imported_categories.split(',')
                    imported_categories = [x.strip() for x in imported_categories]
                    item_categories = pivot_format.get(item_type, {}).get(item, set())
                    item_categories = item_categories.union(imported_categories)
                    pivot_format[item_type][item] = item_categories
        return pivot_format

    def from_user_categories(self, user_categories, file_path, settings):
        format_settings = settings.get('format_settings', {})
        csv_delimiter = format_settings.get('csv_delimiter', ',')
        d = {}
        for category, category_items in user_categories.items():
            for category_item in category_items:
                item, item_type, _ign = category_item
                item_hash = item_type+'|'+item
                item_categories = d.get(item_hash, set())
                item_categories.add(category)
                d[item_hash] = item_categories

        with open(file_path, 'w', encoding='utf-8') as f:
            writer = csv.writer(f, delimiter=csv_delimiter, dialect='excel', quoting=csv.QUOTE_NONNUMERIC)
            writer.writerow(['item','item_type','categories'])
            for item_hash, item_categories in d.items():
                item_type, item = item_hash.split('|')
                categories = ','.join(list(item_categories))
                writer.writerow([item, item_type, categories])

    def validate(self, settings):
        if settings:
            for key in ['csv_delimiter']:
                if not settings.get(key):
                    return _('Settings Error'), _('Some fields contain empty values.')
        return True

    def default_settings(self):
        return {'csv_delimiter': ','}

    def config_widget(self):
        return CategoriesForItemConfigWidget
